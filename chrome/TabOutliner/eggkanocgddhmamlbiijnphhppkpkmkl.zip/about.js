/** @preserve Copyright 2012, 2013, 2014, 2015 by Vladyslav Volovyk. All Rights Reserved. */

document.getElementById('extensionVersionString').innerText  = chrome.runtime.getManifest().version;

//FF_REMOVED_GA ga_screenview('About');



